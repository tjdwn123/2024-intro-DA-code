const express = require('express');
const session = require('express-session');
const bcrypt = require('bcrypt'); // 비밀번호 암호화를 위해
const path = require('path');

const app = express();
const PORT = 3000;
const saltRounds = 10; // 비밀번호 암호화 강도

// -------------------------------------------------
// ★★★★★ 이곳에 허용할 장소의 고정 공인 IP를 입력 ★★★★★
const ALLOWED_IP = "121.121.121.121"; // (예시 IP입니다)
// -------------------------------------------------

// 미들웨어 설정
app.use(express.json()); // JSON 요청 본문 파싱
app.use(express.urlencoded({ extended: true })); // HTML 폼 데이터 파싱
app.use(express.static('public')); // 'public' 폴더의 정적 파일(html, js, css) 제공
app.use(session({
    secret: 'my-super-secret-key-for-attendance',
    resave: false,
    saveUninitialized: true,
    cookie: { maxAge: 60 * 60 * 1000 } // 1시간 세션 유지
}));

// --- (가상) 데이터베이스 ---
// 실제로는 MySQL, MongoDB 등을 사용해야 합니다.

// 1. 관리자가 미리 등록한 회원 (전화번호 기준)
const preRegisteredMembers = [
    { phone: '010-1234-5678', addedBy: 'admin' }	
	,{ phone: '010-4825-7929', addedBy: 'admin' }	
];

// 2. 실제 사이트에 가입한 회원 정보
const users = [];

// 3. 출석 기록
const attendanceDB = [];
// ---

// --- 헬퍼 함수: 로그인 여부 확인 미들웨어 ---
function checkLoggedIn(req, res, next) {
    if (req.session.user) {
        next(); // 로그인 상태면 다음 단계로
    } else {
        res.status(401).json({ success: false, message: '로그인이 필요합니다.' });
    }
}

// --- API 엔드포인트 ---

// [관리자] 회원 전화번호 사전 등록 API
app.post('/admin/add-member', (req, res) => {
    // (실제로는 관리자 인증 로직이 필요함)
    const { phone } = req.body;
    if (!phone) {
        return res.status(400).json({ success: false, message: '전화번호를 입력하세요.' });
    }
    
    if (preRegisteredMembers.find(m => m.phone === phone)) {
        return res.status(400).json({ success: false, message: '이미 등록된 번호입니다.' });
    }
    
    preRegisteredMembers.push({ phone: phone, addedBy: 'admin' });
    console.log('관리자가 회원 추가:', phone);
    res.json({ success: true, message: `${phone} 회원이 추가되었습니다.` });
});

// [사용자] 회원가입 API
app.post('/register', async (req, res) => {
    const { email, password, phone } = req.body;

    // 1. 관리자가 등록한 전화번호인지 확인
    const isPreRegistered = preRegisteredMembers.find(m => m.phone === phone);
    if (!isPreRegistered) {
        return res.status(403).json({ success: false, message: '관리자에 의해 등록되지 않은 전화번호입니다.' });
    }

    // 2. 이미 가입한 이메일인지 확인
    if (users.find(u => u.email === email)) {
        return res.status(400).json({ success: false, message: '이미 사용 중인 이메일입니다.' });
    }

    // 3. 비밀번호 암호화
    const hashedPassword = await bcrypt.hash(password, saltRounds);

    // 4. 회원 정보 저장 (DB 대신 배열에)
    const newUser = {
        id: users.length + 1,
        email: email,
        password: hashedPassword,
        phone: phone
    };
    users.push(newUser);

    console.log('회원가입 성공:', newUser.email);
    res.json({ success: true, message: '회원가입에 성공했습니다. 로그인해주세요.' });
});

// [사용자] 로그인 API
app.post('/login', async (req, res) => {
    const { email, password } = req.body;

    const user = users.find(u => u.email === email);
    if (!user) {
        return res.status(400).json({ success: false, message: '이메일 또는 비밀번호가 올바르지 않습니다.' });
    }

    // 암호화된 비밀번호 비교
    const match = await bcrypt.compare(password, user.password);
    if (match) {
        // 로그인 성공, 세션에 사용자 정보 저장
        req.session.user = {
            id: user.id,
            email: user.email,
            phone: user.phone
        };
        console.log('로그인 성공:', user.email);
        res.json({ success: true, message: '로그인되었습니다.' });
    } else {
        res.status(400).json({ success: false, message: '이메일 또는 비밀번호가 올바르지 않습니다.' });
    }
});

// [사용자] 로그아웃 API
app.post('/logout', (req, res) => {
    req.session.destroy(err => {
        if (err) {
            return res.json({ success: false, message: '로그아웃 실패' });
        }
        res.clearCookie('connect.sid'); // 세션 쿠키 삭제
        res.json({ success: true, message: '로그아웃되었습니다.' });
    });
});

// [사용자] 내 정보 확인 API (로그인 상태 체크용)
app.get('/me', checkLoggedIn, (req, res) => {
    // checkLoggedIn 미들웨어를 통과했으므로 req.session.user는 존재함
    res.json({ success: true, user: req.session.user });
});

// [사용자] 출석하기 API
app.post('/attend', checkLoggedIn, (req, res) => {
    // 1. IP 주소 확인 (checkLoggedIn 통과로 로그인은 확인됨)
    const userIP = req.ip === '::1' ? '127.0.0.1' : req.ip; 
    console.log('접속 IP:', userIP);

    if (userIP !== ALLOWED_IP && userIP !== '127.0.0.1') { // 로컬 테스트용 IP 허용
        return res.status(403).json({ 
            success: false, 
            message: '지정된 장소(WiFi)에서만 출석할 수 있습니다.' 
        });
    }

    // 2. (가상) 오늘 이미 출석했는지 확인 (로직 추가 필요)
    // ...

    // 3. 출석 기록
    const now = new Date();
    const attendanceRecord = {
        userId: req.session.user.id,
        email: req.session.user.email,
        time: now.toLocaleString('ko-KR')
    };
    
    attendanceDB.push(attendanceRecord);
    console.log('출석 완료:', attendanceRecord);

    res.json({
        success: true,
        message: '출석이 완료되었습니다.',
        time: attendanceRecord.time
    });
});

// --- 서버 시작 ---
app.listen(PORT, () => {
    console.log(`서버가 http://localhost:${PORT} 에서 실행 중입니다.`);
    console.log(`출석이 허용된 IP 주소: ${ALLOWED_IP}`);
});