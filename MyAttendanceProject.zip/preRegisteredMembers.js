// --- (가상) 데이터베이스 ---
// 실제로는 MySQL, MongoDB 등을 사용해야 합니다.
// 1. 관리자가 미리 등록한 회원 (전화번호 기준)
const preRegisteredMembers = [
    { phone: '010-1234-5678', addedBy: 'admin' },
    { phone: '010-1234-5678', addedBy: 'admin' }
];
exports.preRegisteredMembers = preRegisteredMembers;
